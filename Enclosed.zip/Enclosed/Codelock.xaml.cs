﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Enclosed
{
    /// <summary>
    /// Interaction logic for Codelock.xaml
    /// </summary>
    public partial class Codelock : Window
    {
        public Codelock()
        {
            InitializeComponent();
        }

        public int MovingOn { get; set; } = 0;

        private void CodelockInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (this.CodelockInput.Text == "KS473")
            {
                MovingOn = 1;
                this.DialogResult = true; // close dialog and return true to caller
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
