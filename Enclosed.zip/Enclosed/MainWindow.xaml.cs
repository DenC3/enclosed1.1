﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Enclosed
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //private bool WasHiddenBefore = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Btn_StartGame(object sender, RoutedEventArgs e)
        {
            TitleScreen.Visibility = Visibility.Collapsed;
            RoomBackground.Visibility = Visibility.Visible;
        }

        private void Btn_ExitGame(object sender, RoutedEventArgs e)
        {
            Close();
        }

        // Room Screen





        private void Img_Obrazek(object sender, MouseButtonEventArgs e)
        {
            //Zmizí po kliknutí aby odhalila klíč a zpřístupní kliknutí na díru ve zdu
            oObrazek.Visibility = Visibility.Collapsed;
            oSuplik.MouseLeftButtonDown -= Img_Nothing;
            oSuplik.MouseLeftButtonDown += Img_Suplik;



            //if (!WasHiddenBefore && oObrazek.Visibility is Visibility.Visible)
            //{
            //    oObrazek.Visibility = Visibility.Hidden;
            //    WasHiddenBefore = true;
            //}
            //else if (oObrazek.Visibility is Visibility.Hidden)
            //{
            //    oObrazek.Visibility = Visibility.Visible;
            //}
        }

        private void Img_Suplik(object sender, MouseButtonEventArgs e)
        {
            //Zobrazí se písmena nebo poznámka která odhalí caesarovu šifru
            Note note = new Note();
            note.Show();
        }

        private void Img_Morse(object sender, MouseButtonEventArgs e)
        {
            //Zobrazí se okno na dekódování morseovky
            BookMorse bookMorse = new BookMorse();
            bookMorse.Show();
        }

        private void Img_Caesar(object sender, MouseButtonEventArgs e)
        {
            //Zobrazi se okno na dekódování caesarovy šifry
            BookCaesar bookCaesar = new BookCaesar();
            bookCaesar.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var codelock = new Codelock();
            bool? result = codelock.ShowDialog();

            if (result == true && codelock.MovingOn == 1)
            {
                RoomBackground.Visibility = Visibility.Collapsed;
                TheEnd.Visibility = Visibility.Visible;
            }
        }

        private void Img_Nothing(object sender, MouseButtonEventArgs e)
        {

        }

        // Final screen





        private void Btn_MainMenu(object sender, RoutedEventArgs e)
        {
            oObrazek.Visibility = Visibility.Visible;
            TitleScreen.Visibility = Visibility.Visible;
            TheEnd.Visibility = Visibility.Collapsed;


            oSuplik.MouseLeftButtonDown -= Img_Suplik;
            oSuplik.MouseLeftButtonDown += Img_Nothing;
        }
    }
}